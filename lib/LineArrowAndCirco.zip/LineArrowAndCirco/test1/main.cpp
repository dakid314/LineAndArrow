
#include <iostream>
#include<cmath>
namespace cr {
#include <cairo/cairo-pdf.h>
#include <cairo/cairo-svg.h>
#include <cairo/cairo.h>
}
int main(){

    

    std::cout<< "\033[1;33m     ____               _" << std::endl
             << "    |  _ \\             | |" << std::endl
             << "    | |_) |_   _       | |  _ __ ___ " << std::endl
             << "    |  _ <| | | |  _   | | | '_ ` _ \\ " << std::endl
             << "    | |_) | |_| | | |__| | | | | | | |" << std::endl
             << "    |____/ \\__, |  \\____/  |_| |_| |_|" << std::endl
             << "            __/ |" << std::endl
             << "           |___/" << std::endl
             << "\033[0m" << std::endl;
    cr::cairo_surface_t* surface;
    cr::cairo_t* pan;
    cr::cairo_t* new_pan;
    
    cr::cairo_t* text_pan;

    surface = cr::cairo_pdf_surface_create("circle.pdf", 500, 500);
    pan = cr::cairo_create(surface);
    new_pan = cr::cairo_create(surface);
    
    text_pan = cr::cairo_create(surface);

    double center_x= 250;
    double center_y = 250;
    double radius = 200;

    cr::cairo_move_to(pan, center_x + radius, center_y);
    cr::cairo_arc(pan, center_x, center_y, radius, 0, 2 * M_PI);
    cr::cairo_set_source_rgb(pan, 0, 0, 0);
    cr::cairo_set_line_width(pan, 10);
    cr::cairo_stroke_preserve(pan);


    cr::cairo_new_sub_path(new_pan);
    cr::cairo_move_to(new_pan, center_x + radius * cos(0), center_y + radius * sin(0));
    cr::cairo_arc(new_pan, center_x, center_y, radius, 0, 72.0/1000.0*2*M_PI);
    cr::cairo_set_source_rgb(new_pan, 0, 0, 1);
    cr::cairo_set_line_width(new_pan, 15);
    cr::cairo_stroke_preserve(new_pan);

    cr::cairo_new_sub_path(new_pan);
    cr::cairo_move_to(new_pan, center_x + radius * cos(100.0 / 1000.0 * 2 * M_PI), center_y + radius * sin(100.0 / 1000.0 * 2 * M_PI));
    cr::cairo_arc(new_pan, center_x, center_y, radius, 100.0 / 1000.0 * 2 * M_PI, 150.0 / 1000.0 * 2 * M_PI);
    cr::cairo_set_source_rgb(new_pan, 0, 1, 0);
    cr::cairo_set_line_width(new_pan, 15);
    cr::cairo_stroke_preserve(new_pan);

    cr::cairo_select_font_face(text_pan, "Arial", cr::CAIRO_FONT_SLANT_NORMAL, cr::CAIRO_FONT_WEIGHT_BOLD);
    cr::cairo_set_font_size(text_pan, 10);
    cr::cairo_set_source_rgb(text_pan, 1, 0, 1);
    cr::cairo_move_to(text_pan, center_x + radius * cos(72.0 / 1000.0  * M_PI), center_y + radius * sin(72.0 / 1000.0  * M_PI));
    cr::cairo_show_text(text_pan, "gene1");

    cr::cairo_new_sub_path(text_pan);
    cr::cairo_select_font_face(text_pan, "Arial", cr::CAIRO_FONT_SLANT_NORMAL, cr::CAIRO_FONT_WEIGHT_BOLD);
    cr::cairo_set_font_size(text_pan, 10);
    cr::cairo_set_source_rgb(text_pan, 0, 1, 1);
    cr::cairo_move_to(text_pan, center_x + radius * cos(100.0 / 1000.0 * M_PI + 150.0 / 1000.0 * M_PI), center_y + radius * sin(100.0 / 1000.0 * M_PI + 150.0 / 1000.0 * M_PI));
    cr::cairo_show_text(text_pan, "gene2");

    cr::cairo_destroy(pan);
    cr::cairo_destroy(new_pan);
    cr::cairo_destroy(text_pan);
    cr::cairo_surface_destroy(surface);
}